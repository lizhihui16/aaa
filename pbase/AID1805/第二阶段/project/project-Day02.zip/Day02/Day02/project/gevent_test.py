import gevent 

def foo(a,b):
    print("Running in foo",a)
    gevent.sleep(2)
    print("switch to foo again")

def bar():
    print("Running in bar")
    gevent.sleep(3)
    print("switch to bar again")

#将两个函数变为协程
f = gevent.spawn(foo,1,2)
b = gevent.spawn(bar)

#回收
gevent.joinall([f,b])