#httpserver 配置文件

HOST = '0.0.0.0'
PORT = 8000
ADDR = (HOST,PORT)

#使用模块和应用
MODULE_PATH = '.'   #使用框架的路径
MODULE = 'WebFrame' #要使用的框架
APP = 'app'         #要使用的应用 