from pymongo import MongoClient
import gridfs 

conn = MongoClient("localhost",27017)
db = conn.grid 

#通过 GridFS获取集合对象
#fs 即为存储大文件对象
fs = gridfs.GridFS(db)

#通过查找获取游标
cursor = fs.find()

#获取每一个文件的对象
for file in cursor:
    #通过filename属性获取文件名
    if file.filename == 'abc.mp4':
        with open(file.filename,'wb') as f:
            while True:
                #通过file.read从数据库获取文件内容
                data = file.read(4096)
                if not data:
                    break
                f.write(data)
conn.close()


