from socketserver import * 

#多进程tcp并发


#创建指定类型的服务器
# class Server(ForkingMixIn,TCPServer):
class Server(ForkingTCPServer):
    pass 

#处理具体请求
class Handler(StreamRequestHandler):
    def handle(self):
        #self.request 相当于　accept 返回的套接字
        print("Connect from",\
            self.request.getpeername())
        while True:
            data = self.request.recv(1024).decode()
            if not data:
                break
            print(data)
            self.request.send(b"Receive your message")

#生成服务器对象
server = Server(('0.0.0.0',9999),Handler)

#启动服务器
server.serve_forever()

