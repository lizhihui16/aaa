from socket import * 
import sys 

#从命令行传入ip和端口
#判断linux命令行输入的命令，可以理解为一个input函数读取的linux命令行输入的的命令，以空格隔开
# 将读取的字符串以split函数分解为三个对象，存入一个列表中。
HOST = sys.argv[1]
PORT = int(sys.argv[2])
ADDR = (HOST,PORT)

#创建无连接的数据报套接字，括号内不可为空，为空的话，默认创建TCP
sockfd = socket(AF_INET,SOCK_DGRAM)

#绑定地址
sockfd.bind(ADDR)
# 因为是无连接的，所以不需要监听连接数，也不需要创建监听队列。


#以下循环作用：使服务器永久处于等待状态，接受客户端的消息
while True:
    #接受消息
    data,addr = sockfd.recvfrom(5)
    print("Receive from %s:%s"%(addr,data.decode()))

    #发送消息
    sockfd.sendto("收到你的消息".encode(),addr)

#关闭套接字
sockfd.close()


