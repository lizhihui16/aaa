#tcp_client.py 
from socket import * 

#创建传输套接字 tcp 默认参数即可 
sockfd = socket()

#传输套接字发起链接请求
sockfd.connect(('127.0.0.1',8888))

while True:
    data = input("发送>>")
	
	#无信息需要发送情况下，结束循环，执行sockfd.close()行，关闭传输套接字
    if not data:
        break 

    #发送消息 bytes格式，即utf-8格式
    sockfd.send(data.encode())
	
	#接受消息，并解码
    data = sockfd.recv(1024).decode()
    print(data)

#关闭套接字
sockfd.close()