#tcp_server.py
from socket import *

#创建tcp套接字,返回一个负责监听的套接字
sockfd = socket(AF_INET,SOCK_STREAM)

#绑定IP和端口
sockfd.bind(("127.0.0.1",8888))

#监听套接字负责处理并创建连接序列，以免过多连接，占用内存，影响服务器处理效率。
sockfd.listen(5)

while True:
    #等待客户端链接
    print("Waiting for connect....")

	# 监听套接字调用accept方法，返回一个传输套接字文件描述符
    connfd,addr = sockfd.accept()
    print("Connect from",addr)

    while True:
        #传输套接字接收消息
        data = connfd.recv(1024)

		#接受不到消息，就停止循环，运行到 connfd.close(),关闭传输套接字
        if not data:
            break
        print("Receive message >>",data.decode())
		
		#注：接受和发送直接是存在对收到信息逻辑处理的，要么调用数据库查询，要么显示给人去做判断等。

        #传输套接字发送消息
        n = connfd.send(b"Receive your message\n")
        print("Send %d bytes data"%n)
    
	#关闭传输套接字
    connfd.close()

#关闭监听套接字
sockfd.close()