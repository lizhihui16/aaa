# -*- coding: utf-8 -*-
from socket import * 
import sys 

#判断linux命令行输入的命令，可以理解为一个input函数读取的linux命令行输入的的命令，以空格隔开
# 将读取的字符串以split函数分解为三个对象，存入一个列表中。
if len(sys.argv) < 3:
    print('''
        argv is error !!
        run as 
        python3  udp_client.py 127.0.0.1 8888
        ''')
    raise 

HOST = sys.argv[1]
PORT = int(sys.argv[2])
SERVER_ADDR = (HOST,PORT)

#创建套接字
sockfd = socket(AF_INET,SOCK_DGRAM)

while True:
    data = input("消息:")
    if not data:
        break
    #给服务器发送
    sockfd.sendto(data.encode(),SERVER_ADDR)
    #收到服务器回复
    data,addr = sockfd.recvfrom(1024)
    print("从服务器收到:",data.decode())

sockfd.close()


