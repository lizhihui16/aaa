def fun(a):
    a = "Nihao China"

s = "hello world"

fun(s)

print(s)
