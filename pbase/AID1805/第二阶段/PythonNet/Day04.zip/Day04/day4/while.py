#!/usr/bin/env python3
from time import sleep,ctime 

while True:
    sleep(2)
    print(ctime())

    