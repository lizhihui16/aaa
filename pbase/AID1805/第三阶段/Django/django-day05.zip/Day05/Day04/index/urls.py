from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是 /01_add , 交给 add_views 处理
    url(r'^01_add/$',add_views),
    # 访问路径是 /02_query, 交给 query_views 处理
    url(r'^02_query/$',query_views),
    # 访问路径是 /03_queryall,交给queryall_views处理
    url(r'^03_queryall/$',queryall_views,name='all'),
    # 访问路径是 /04_get , 交给get_views去处理
    url(r'^04_get/$',get_views),
    # 访问路径是 /05_getau/(\d+) 交给getau_views去处理
    url(r'^05_getau/(\d+)/$',getau_views,name='getau'),
    # 访问路径是 /06_filter/ 交给 filter_views
    url(r'^06_filter/$',filter_views),
    # 访问路径是 /07_email/ 交给 email_views
    url(r'^07_email/$',email_views),
    # 访问路径是 /08_delete/(\d+) 交给 delete_views
    url(r'^08_delete/(\d+)/$',delete_views,name='del'),
    # 访问路径是 /09_updateage/ 交给 updateage_views
    url(r'^09_updateage/$',updateAge_views),

]