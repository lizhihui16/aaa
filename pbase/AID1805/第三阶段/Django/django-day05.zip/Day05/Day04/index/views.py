from django.db.models import F, Q
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse

from .models import *

# Create your views here.

# /01_add 所对应的视图

def add_views(request):
    # 向 Author 实体中增加一条数据
    # ret = Author.objects.create(name='老舍',age=85,email='laoshe@163.com')
    # return HttpResponse(ret)

    # 使用方式2 向Author表中增加数据
    # author = Author(name='巴金',age=75,email='bajin@163.com')
    # ret = author.save()
    # return HttpResponse(ret)

    # 使用方式3 向Author表中增加数据
    dic = {
        'name':'冰心',
        'age':'96',
        'email':'bingxin@163.com'
    }
    author = Author(**dic)
    author.save()
    return HttpResponse('Add OK')


def query_views(request):
    # 1. 查询 Author 实体(表)中所有的数据
    # authors = Author.objects.all()
    # # 循环便利 authors 中的每条记录
    # for au in authors:
    #     print(au.name,au.age,au.email)

    # 2. 查询 Author 实体中name和age两个列的信息
    # authors = Author.objects.values('name','age')
    # # print(authors)
    # for au in authors:
    #     print(au['name'],au['age'])

    # 3.查询 Author 实体中name和age两个列的信息
    # authors = Author.objects.values_list('name','age')
    # print(authors)

    # 4.Author表中的数据按照年龄降序排序
    authors = Author.objects.order_by('-age')
    print(authors)





    return HttpResponse('Query OK')

def queryall_views(request):
    # 查询所有数据按年龄降序排序
    # authors = Author.objects.order_by('-age')

    # 查询所有isActive为True的数据,并按年龄降序排序
    authors = Author.objects.filter(isActive=True).order_by("-age")
    return render(request,'01_all.html',locals())


def get_views(request):
    author=Author.objects.get(name='舒庆春')
    print(author)
    return HttpResponse('Query OK')

def getau_views(request,id):
    au = Author.objects.get(id=id)
    return render(request,'02_author.html',locals())


def filter_views(request):
    # auList = Author.objects.filter(id=1,name='老舍')
    auList = Author.objects.filter(name='莫言')
    print(auList)
    return HttpResponse('Query OK')

def email_views(request):
    auList=Author.objects.filter(email__contains='a')
    for au in auList:
        print(au.name,au.age,au.email)
    return HttpResponse("Query OK")

def delete_views(request,id):
    au = Author.objects.get(id=id)
    au.isActive = False
    au.save()

    # 使用转发
    # return queryall_views(request)

    # 使用重定向
    # return HttpResponseRedirect('/03_queryall/')
    url = reverse('all')
    print(url)
    return redirect(url)

def updateAge_views(request):
   # Author.objects.all().update(age=F('age')+10)

   # 查询id=1或年龄大于100的author的信息
   auList=Author.objects.filter(Q(id=1)|Q(age__gt=100),isActive=1)
   for au in auList:
       print(au.name,au.age,au.email)
   return redirect(reverse('all'))









