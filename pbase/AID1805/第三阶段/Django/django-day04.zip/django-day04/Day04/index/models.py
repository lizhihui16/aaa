from django.db import models

# Create your models here.
# 创建 Publisher 实体类
# 表示 出版社 的信息,属性如下:
# 1.name : 出版社的名称(varchar,string)
# 2.address : 出版社的地址
# 3.city : 出版社所在城市
# 4.country : 出版社所在国家
# 5.website : 出版社的网址
class Publisher(models.Model):
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=20)
    country = models.CharField(max_length=20)
    website = models.URLField()

class Author(models.Model):
    name = models.CharField(max_length=50)
    age = models.IntegerField()
    email = models.EmailField(null=True)

    def __str__(self):
        return self.name

class Book(models.Model):
    title = models.CharField(max_length=50)
    publicate_date = models.DateField()








