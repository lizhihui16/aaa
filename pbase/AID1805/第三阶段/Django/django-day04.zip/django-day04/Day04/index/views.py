from django.http import HttpResponse
from django.shortcuts import render
from .models import *

# Create your views here.

# /01_add 所对应的视图

def add_views(request):
    # 向 Author 实体中增加一条数据
    # ret = Author.objects.create(name='老舍',age=85,email='laoshe@163.com')
    # return HttpResponse(ret)

    # 使用方式2 向Author表中增加数据
    # author = Author(name='巴金',age=75,email='bajin@163.com')
    # ret = author.save()
    # return HttpResponse(ret)

    # 使用方式3 向Author表中增加数据
    dic = {
        'name':'冰心',
        'age':'96',
        'email':'bingxin@163.com'
    }
    author = Author(**dic)
    author.save()
    return HttpResponse('Add OK')


def query_views(request):
    # 1. 查询 Author 实体(表)中所有的数据
    # authors = Author.objects.all()
    # # 循环便利 authors 中的每条记录
    # for au in authors:
    #     print(au.name,au.age,au.email)

    # 2. 查询 Author 实体中name和age两个列的信息
    # authors = Author.objects.values('name','age')
    # # print(authors)
    # for au in authors:
    #     print(au['name'],au['age'])

    # 3.查询 Author 实体中name和age两个列的信息
    # authors = Author.objects.values_list('name','age')
    # print(authors)

    # 4.Author表中的数据按照年龄降序排序
    authors = Author.objects.order_by('-age')
    print(authors)





    return HttpResponse('Query OK')





