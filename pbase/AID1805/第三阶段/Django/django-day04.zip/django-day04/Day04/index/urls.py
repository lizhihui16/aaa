from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是 /01_add , 交给 add_views 处理
    url(r'^01_add/$',add_views),
    # 访问路径是 /02_query, 交给 query_views 处理
    url(r'^02_query/$',query_views),
]