from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是 /01_request/ 的时候,交给request_views去处理
    url(r'^01_request/$',request_views),
    # 访问路径是 /02_meta/ 的时候,交给meta_views去处理
    url(r'^02_meta/$',meta_views),
    # 访问路径是 /03_form/ 的时候,交给form_views去处理
    url(r'^03_form/$',form_views),
    # 访问路径是 /04_get/ 的时候,交给get_views去处理
    url(r'^04_get/$',get_views,name='get'),
    # 访问路径是 /05_post/ 的时候,交给post_views去处理
    url(r'^05_post/$',post_views,name='post'),
    # 访问路径是 /06_login/ 的时候,交给login_views去处理
    url(r'^06_login/$',login_views),
    # 访问路径是 /07_remark/ 的时候,交给remark_views去处理
    url(r'^07_remark/$',remark_views),
    # 访问路径是 /08_userLogin/的时候,交给userLogin_views处理
    url(r'^08_userLogin/$',userLogin_views),
    # 访问路径是 /09_register/的时候,交给register_views处理
    url(r'^09_register/$',register_views),
    # 访问路径是 /10_login/的时候,交给loginform_views去处理
    url(r'^10_login/$',loginform_views),
    # 访问路径是 /11_register/的时候,交给registerform_views去处理
    url(r'^11_register/$',registerform_views),
]

urlpatterns += [
    # 访问路径是 /12_widget1/的时候,交给widget1_views去处理
    url(r'12_widget1/$',widget1_views),
]

urlpatterns += [
    # 访问路径是 /13_cookie1/的时候,交给cookie1_views去处理
    url(r'^13_cookie1/$',cookie1_views),
    # 访问路径是 /14_cookie2/的时候,交给cookie2_views去处理
    url(r'^14_cookie2/$',cookie2_views),
    # 访问路径是 /15_login/ 的时候,交给login15_views去处理
    url(r'^15_login/$',login15_views),
    # 访问路径是 /16_getCookie/的时候,交给getcookie_views去处理
    url(r'^16_getCookie/$',getcookie_views),
    #
    url(r'^17_logout/$',logout_views)
]






