from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from .forms import *
from .models import *

# Create your views here.

def request_views(request):
    # request,类型就是 HttpRequest
    # request 封装的是所有与请求相关的内容
    # print(dir(request))

    # 协议 (方案)
    scheme = request.scheme
    # 请求主体
    body = request.body
    # 请求资源的具体路径
    path = request.path
    # 请求主机的地址 / 域名
    host = request.get_host()
    # 请求方法
    method = request.method
    # get方式请求数据
    get = request.GET
    # post方式请求数据
    post = request.POST
    # cookie 中的数据
    cookies = request.COOKIES
    # 请求的元数据
    meta = request.META
    return render(request,'01_request.html',locals())


def meta_views(request):
    if 'HTTP_REFERER' in request.META:
        print('请求源地址为:'+request.META['HTTP_REFERER'])
    return HttpResponse("Request OK")

# /03_form/
def form_views(request):
    return render(request,'02_form.html')

# /04_get/
def get_views(request):
    # print(request.GET)
    uname = request.GET['uname']
    upwd = request.GET['upwd']
    return HttpResponse("用户名:"+uname+",密码:"+upwd)

# /05_post/
def post_views(request):
    uname = request.POST['uname']
    upwd = request.POST['upwd']
    return HttpResponse("用户名:" + uname + ",密码:" + upwd)

# /06_login/
def login_views(request):
    if request.method == "GET":
        return render(request, '03_login.html')
    else:
        uname = request.POST['uname']
        upwd = request.POST['upwd']
        return HttpResponse('uname:'+uname+',upwd:'+upwd)

# /07_remark/
def remark_views(request):
    form = RemarkForm()
    return render(request,'04_remark.html',locals())


# /08_userLogin/
def userLogin_views(request):
    if request.method == 'GET':
        form = LoginForm()
        return render(request,'05_login.html',locals())
    else:
        # 1.手动接收提交的数据
        # uname = request.POST['uname']
        # upwd = request.POST['upwd']

        # 2.自动接收提交的数据
        # 2.1 通过 forms.Form的构造,接收request.POST
        form = LoginForm(request.POST)
        # 2.2 is_valid()
        if form.is_valid():
            # 2.3 form.cleaned_data
            cd = form.cleaned_data
            print(cd)
            print(request.POST)
            uname = cd['uname']
            upwd = cd['upwd']
            uList = Users.objects.filter(uname=uname,upwd=upwd)
            if uList:
                return HttpResponse('登录成功')
            else:
               form = LoginForm()
               errMsg = "用户名或密码不正确"
               return render(request,'05_login.html',locals())





# /09_register/
def register_views(request):
    if request.method == "GET":
        form = RegisterForm()
        return render(request,'06_register.html',locals())
    else:
        form = RegisterForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            uname = cd['uname']
            uList = Users.objects.filter(uname=uname)
            if uList:
                errMsg = "用户名已经存在"
                form = RegisterForm()
                return render(request,'06_register.html',locals())
            else:
                Users(**cd).save()
                return HttpResponse('注册成功')


# /10_login/
def loginform_views(request):
    if request.method == 'GET':
        form = UsersLoginForm()
        return render(request,'07_login.html',locals())

def registerform_views(request):
    if request.method == 'GET':
        form = UsersRegisterForm()
        return render(request,'08_register.html',locals())


# /12_widget1/
def widget1_views(request):
    form = Widget2Form()
    return render(request,'09_widget.html',locals())



# /13_cookie1/
def cookie1_views(request):
    resp = HttpResponse('添加cookie成功')
    resp.set_cookie('uid','1001',60*60*24*366)
    return resp

# /14_cookie2/
def cookie2_views(request):
    resp = HttpResponseRedirect('/06_login/')
    resp.set_cookie('uname','zsf',60*60*24*31)
    return resp
# /15_login/
def login15_views(request):
    if request.method=='GET':
        # 判断session中是否有登录信息,如果有的话,跳转至首页,否则,再判断cookies
        if 'uid' in request.session and 'uname' in request.session:
            # 取出session中的数据发送到首页上
            uid = request.session['uid']
            uname = request.session['uname']
            return render(request,'11_index.html',locals())
        else:
            # 判断cookie中是否有uid和uname
            if 'uid' in request.COOKIES and 'uname' in request.COOKIES:
                # 如果有的话,则去往首页
                return render(request,'11_index.html')
            else:
                # 否则显示登录页
                form = Widget2Form()
                return render(request,'10_login.html',locals())
    else:
        uname = request.POST['uname']
        upwd = request.POST['upwd']
        uList = Users.objects.filter(uname=uname,upwd=upwd)
        if uList:
            # set login info to session
            request.session['uid']=uList[0].id
            request.session['uname']=uname

            resp=render(request,'11_index.html')
            #判断是否勾选了 记住密码
            if 'isSaved' in request.POST:
                uid = uList[0].id
                expires = 60*60*24*366
                resp.set_cookie('uid',uid,expires)
                resp.set_cookie('uname',uname,expires)
            return resp
        else:
            #登录失败的处理
            form = Widget2Form()
            return render(request,'10_login.html',locals())


#/16_getCookie/
def getcookie_views(request):
    #print(request.COOKIES)
    print('uid:'+request.COOKIES['uid'])
    print('uname:'+request.COOKIES['uname'])
    return HttpResponse('Get Cookie OK')

#/17_logout/
def logout_views(request):
    if 'uid' in request.session and 'uname' in request.session:
        del request.session['uid']
        del request.session['uname']
        return redirect('/15_login/')
    else:
        return HttpResponse('Dont click!!!')

