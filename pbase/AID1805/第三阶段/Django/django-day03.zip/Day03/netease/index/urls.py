from django.conf.urls import url
from .views import *
# http://localhost:8000/*****
urlpatterns = [
    # 访问路径为空的时候，交给index_views去处理
    url(r'^$',index_views),
    # 访问路径是 /login 的时候，交给 login_views 去处理
    url(r'^login/$',login_views),
]

urlpatterns += [
    # 访问路径 /01_getTemp/
    url(r'^01_getTemp/$',getTemp_views),
    # 访问路径 /02_getTemp/
    url(r'^02_getTemp/$',getTemp1_views),
    # 访问路径 /03_var/
    url(r'^03_var/$',var_views),
    # 访问路径 /04_static/
    url(r'^04_static/$',static_views),
    # 访问路径 /05_temp/
    url(r'^05_temp/$',temp_views),

]







