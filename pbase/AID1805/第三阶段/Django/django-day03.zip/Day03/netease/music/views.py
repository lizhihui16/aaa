from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from django.urls import reverse


def index_views(request):
    return HttpResponse('这是music应用中的index访问路径')

def show_views(request):
    return HttpResponse('这是music应用中的show视图')

# /show/四位数字/两位数字
def show1_views(request,num1,num2):
    return HttpResponse('参数1:'+num1+',参数2:'+num2)

    #return render(request,'05_arg.html',locals())

# /show_reverse
def reverse_views(request):
    # 将 show 别名解析成对应的url (无参)
    # url = reverse('show')

    # 将 show_arg 别名解析成对应的url (带参)
    url = reverse('show_arg',args=('2018','09'))
    return HttpResponse('解析地址为:'+url)












