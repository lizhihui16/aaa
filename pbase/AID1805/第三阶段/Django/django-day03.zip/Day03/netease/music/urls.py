from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是 index(/music/index) 的时候，交给index_views去处理
    url(r'^$',index_views),
    # 访问路径是 show (/music/show) 的时候，交给show_views
    url(r'^show/$',show_views,name='show'),
    # 访问路径是 show/四位数字/两位数字的时候，交给show1_views
    url(r'^show/(\d{4})/(\d{2})/$',show1_views,name='show_arg'),
    # 访问路径是 show_reverse 的时候，交给reverse_views去处理
    url(r'^show_reverse/$',reverse_views),
]










