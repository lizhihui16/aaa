from django.shortcuts import render

# Create your views here.
def index_views(request):
    return render(request,'index.html')

# /login 对应的视图
def login_views(request):
    return render(request,'login.html')

# /register 对应的视图
def register_views(request):
    return render(request,'register.html')

