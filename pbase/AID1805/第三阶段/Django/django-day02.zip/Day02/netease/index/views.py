from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

# Create your views here.
def index_views(request):
    return HttpResponse('这是网站的首页')


def login_views(request):
    return HttpResponse('这是登录页面...')

# /01_getTemp/ 的视图处理函数
def getTemp_views(request):
    #1.通过 loader 加载模板
    t = loader.get_template('01_template.html')
    #2.将模板转换为字符串
    html = t.render()
    #3.将字符串响应给客户端
    return HttpResponse(html)


def getTemp1_views(request):
    return render(request,'01_template.html')

def var_views(request):
    # 声明变量字典
    l = ['金毛狮王','白眉鹰王','青翼斧王']
    t = ('潘金莲','西门庆','武大郎')
    dic = {
        'SHZ':'水浒传',
        'XYJ':'西游记',
        'HLM':'红楼梦',
    }
    f = fun(35,53)
    dog = Dog()
    print(locals())
    return render(request, '02_var.html', locals())
    # vars = {
    #     'num':15,
    #     'str':'模板中的字符串变量',
    #     'tup':t,
    #     'list':l,
    #     'dic':dic,
    #     'fun':fun(35,53),
    #     'dog':Dog()
    # }




def fun(num1,num2):
    return num1+num2

class Dog(object):
    name = '阿拉斯加'
    def eat(self):
        return '吃狗粮'




