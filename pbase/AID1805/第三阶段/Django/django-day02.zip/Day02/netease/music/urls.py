from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是 index(/music/index) 的时候，交给index_views去处理
    url(r'^$',index_views),
]