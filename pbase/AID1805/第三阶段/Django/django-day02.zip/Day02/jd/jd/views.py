from django.http import HttpResponse
# 编写视图函数，一个函数就是一个独立的处理程序，就是一个独立的视图

def run_views(request):
    # 向客户端浏览器响应输出一句话
    return HttpResponse("<h1>我的第一个DJANGO程序</h1>")


# http://localhost:8000/run/两位数字
# num 表示的就是路径各种的 两位数字
def run1_views(request,num):
    return HttpResponse('传递进来的参数：'+num)

# url(r'^run/(\d{4})/(\d{2})/$',run2_views),
# /run/(\d{4})/(\d{2})
# num1 : (\d{4})
# num2 : (\d{2})
def run2_views(request,num1,num2):
    return HttpResponse('参数1:'+num1+'，参数2:'+num2)

def show_views(request,name,age):
    return HttpResponse('name:'+name+',age:'+age)












