from django.contrib import admin
from .models import *

# 定义 Author 的高级管理类
class AuthorAdmin(admin.ModelAdmin):
    #1.指定在列表页中显示的字段们
    list_display = ('name','age','email')
    #2.指定能够链接到详情页的链接们
    list_display_links = ('name','email')
    #3.指定在列表页中就允许被修改的字段们
    list_editable = ('age',)
    #4.指定允许被搜索的字段们
    search_fields = ('name','email')
    #5.指定右侧过滤器中允许筛选的字段们
    list_filter = ('name','email')
    #7.指定在详情页中显示的字段们以及顺序
    # fields = ('age','name')
    #8.指定在详情页中的字段分组
    fieldsets = (
        #分组1
        (
            "基本选项",{
                "fields":('name','age','publisher'),
            }
        ),
        #分组2
        (
            "高级选项",{
                "fields":('email','isActive'),
                "classes":("collapse",)
            }
        )
    )


# 定义 Book 的高级管理类
class BookAdmin(admin.ModelAdmin):
    #6.增加时间选择器
    date_hierarchy = "publicate_date"

# 定义Publisher的高级管理类
class PublisherAdmin(admin.ModelAdmin):
    # 1.在列表页中显示name, address, city属性值
    list_display = ('name','address','city')
    # 2.address和city是可编辑的
    list_editable = ('address','city')
    # 3.右侧显示过滤器, 允许按照city和country进行筛选
    list_filter = ('city','country')
    # 4.分组显示name, address, city为基本选项country, website为高级选项, 并可折叠
    fieldsets = (
        #分组1
        (
            '基本选项',{
                "fields":('name','address','city')
            }
        ),
        # 分组2
        (
            '高级选项',{
                "fields":('country','website'),
                "classes":('collapse',)
            }
        )
    )


# Register your models here.
admin.site.register(Author,AuthorAdmin)
admin.site.register(Book,BookAdmin)
admin.site.register(Publisher,PublisherAdmin)
admin.site.register(Wife)
