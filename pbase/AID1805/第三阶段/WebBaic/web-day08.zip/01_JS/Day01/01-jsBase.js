console.log('这是在外部JS中执行的内容');
document.write('外部文件显示在网页中的内容');
window.alert('该语句的作用是?');