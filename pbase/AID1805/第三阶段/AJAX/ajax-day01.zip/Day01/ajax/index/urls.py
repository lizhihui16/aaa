from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是　/01_xmlhttp/ 交给xmlhttp_viewｓ去处理
    url(r'^01_xmlhttp/$',xmlhttp_views),
    # 访问路径是　/02_get/ 交给get01_views 去处理
    url(r'^02_get/$',get01_views),
    # 访问路径是　/02_server/ 交给server02_views
    url(r'^02_server/$',server02_views),
    # 访问路径是　/03_get/ 交给get03_views 去处理
    url(r'^03_get/$',get03_views),
    # 访问路径是　/03_server/ 交给server03_views去处理
    url(r'^03_server/$',server03_views),
    # 访问路径是　/04_post/ 交给post04_views去处理
    url(r'^04_post/$',post04_views),
    # 访问路径是 /04_server/ 交给server04_views去处理
    url(r'^04_server/$',server04_views),
    url(r'^05_form/$',form_views),
]






