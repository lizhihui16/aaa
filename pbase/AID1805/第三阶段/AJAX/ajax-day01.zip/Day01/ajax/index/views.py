from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def xmlhttp_views(request):
    return render(request,'01_xmlhttp.html')

# /02_get/
def get01_views(request):
    return render(request,'02_get.html')

# /02_server/
def server02_views(request):
    return HttpResponse('这是服务器端响应回去的数据')

# /03_get/
def get03_views(request):
    return render(request,'03_get.html')

# /03_server/
def server03_views(request):
    uname = request.GET['uname']
    return HttpResponse('欢迎：'+uname)

def post04_views(request):
    return render(request,'04_post.html')

def server04_views(request):
    uname = request.POST['uname']
    upwd = request.POST['upwd']
    return HttpResponse('用户名:'+uname+',密码:'+upwd)

def form_views(request):
    return render(request,'05_form.html')

