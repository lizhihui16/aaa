from django.conf.urls import url
from .views import *
urlpatterns = [
    url(r'^01_setCookie/$',setCookie_views),
    url(r'^02_getCookie/$',getCookie_views),
    url(r'^03_htmlcookie/$',htmlcookie_views),
]