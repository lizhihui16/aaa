from django.http import HttpResponse
from django.shortcuts import render
import json

# Create your views here.
def setCookie_views(request):
    uname='张三丰'
    #将ｕｎａｍｅ转换成ｕｎｉｃｏｄｅ
    uname=json.dumps(uname)
    print(uname)
    resp = HttpResponse("Set Cookie OK")
    resp.set_cookie('uname',uname,60*60*24)
    return resp

def getCookie_views(request):
    uname=request.COOKIES['uname']
    #　将unicode码转换成中文
    uname=json.loads(uname)
    return HttpResponse(uname)

def htmlcookie_views(request):
    return render(request,'01_cookie.html')







