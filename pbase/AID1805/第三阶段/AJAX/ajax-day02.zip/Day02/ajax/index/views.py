import json

from django.core import serializers
from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from index.models import User


def xmlhttp_views(request):
    return render(request,'01_xmlhttp.html')

# /02_get/
def get01_views(request):
    return render(request,'02_get.html')

# /02_server/
def server02_views(request):
    return HttpResponse('这是服务器端响应回去的数据')

# /03_get/
def get03_views(request):
    return render(request,'03_get.html')

# /03_server/
def server03_views(request):
    uname = request.GET['uname']
    return HttpResponse('欢迎：'+uname)

def post04_views(request):
    return render(request,'04_post.html')

def server04_views(request):
    uname = request.POST['uname']
    upwd = request.POST['upwd']
    return HttpResponse('用户名:'+uname+',密码:'+upwd)

def form_views(request):
    return render(request,'05_form.html')

def post06_views(request):
    return render(request,'06_post.html')


def server06_views(request):
    uname = request.POST['uname']
    return HttpResponse('欢迎:'+uname)

def register_views(request):
    return render(request,'07_register.html')

def server07_views(request):
    uname = request.POST['uname']
    uList=User.objects.filter(uname=uname)
    if uList:
        return HttpResponse('用户名称已经存在')
    else:
        return HttpResponse('通过')



def json_views(request):
    return render(request,'08_json.html')

def server08_views(request):
    # 将元组转换为JSON格式字符串
    # tup = ("老魏","隔壁老王","吕泽","蒙蒙")
    # jsonStr=json.dumps(tup)
    # print("JSON格式字符串："+jsonStr)

    # 将列表转换为JSON格式字符串
    # uList = ["魏明择","王伟超","吕泽","赵萌萌"]
    # jsonStr=json.dumps(uList)
    # print("json格式的字符串:"+jsonStr)

    #　将字典转换为JSON格式的字符串
    # dic = {
    #     'name':"WangWc",
    #     "gender":"Male",
    #     "age":32
    # }
    # jsonStr=json.dumps(dic)
    # print("son格式的字符串:"+jsonStr)


    # 通过一个列表，包含若干个字典，每个字典表示一个人的信息(name,age,gender)
    # uList = [
    #     {
    #         "name":"Wang Weichao",
    #         "age":32,
    #         "gender":"男"
    #     },
    #     {
    #         "name":"Wang Wc",
    #         "age":32,
    #         "gender":"Male"
    #     }
    # ]
    # jsonStr=json.dumps(uList)


    # 查询User表中所有的数据再转换成JSON格式字符串
    # users = User.objects.all()
    # jsonStr=serializers.serialize('json',users)

    # 查询User表中的单条数据
    # user=User.objects.get(id=1)
    # jsonStr=json.dumps(user) # 错误
    # jsonStr=serializers.serialize('json',user)　#错误
    # jsonStr=json.dumps(user.to_dict())

    # 查询User表中所有的数据，并转换成JSON格式字符串响应给前端
    users = User.objects.all()
    jsonStr = serializers.serialize('json',users)
    return HttpResponse(jsonStr)

def jqload_views(request):
    return render(request,'09_jqload.html')

def server09_views(request):
    uname = request.GET['uname']
    uage = request.GET['uage']

    users = User.objects.all()
    jsonStr = serializers.serialize('json',users)

    return HttpResponse(jsonStr)

    # return HttpResponse('使用jquery的load发送的请求')






