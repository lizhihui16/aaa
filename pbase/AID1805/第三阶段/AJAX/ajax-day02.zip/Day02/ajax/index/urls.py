from django.conf.urls import url
from .views import *
urlpatterns = [
    # 访问路径是　/01_xmlhttp/ 交给xmlhttp_viewｓ去处理
    url(r'^01_xmlhttp/$',xmlhttp_views),
    # 访问路径是　/02_get/ 交给get01_views 去处理
    url(r'^02_get/$',get01_views),
    # 访问路径是　/02_server/ 交给server02_views
    url(r'^02_server/$',server02_views),
    # 访问路径是　/03_get/ 交给get03_views 去处理
    url(r'^03_get/$',get03_views),
    # 访问路径是　/03_server/ 交给server03_views去处理
    url(r'^03_server/$',server03_views),
    # 访问路径是　/04_post/ 交给post04_views去处理
    url(r'^04_post/$',post04_views),
    # 访问路径是 /04_server/ 交给server04_views去处理
    url(r'^04_server/$',server04_views),
    url(r'^05_form/$',form_views),
    # 访问路径是 /06_post/　交给post06_views处理　
    url(r'^06_post/$',post06_views),
    url(r'^06_server/$',server06_views),
    # 访问路径是　/07_register/ 交给register_views去处理
    url(r'^07_register/$',register_views),
    url(r'^07_server/$',server07_views),
    # 访问路径是　/08_json/ 交给json_views去处理
    url(r'^08_json/$',json_views),
    url(r'^08_server/$',server08_views),
    #访问路径是　/09_jqload/　交给jqload_views去处理
    url(r'^09_jqload/$',jqload_views),
    url(r'^09_server/$',server09_views)
]






