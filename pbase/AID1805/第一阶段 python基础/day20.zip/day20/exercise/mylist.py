

class MyList:
    class MyIterator:
        def __init__(self, lst):
            self.data = lst  # 绑定要迭代的列表　
            self.index = 0  # 迭代的起始位置

        def __next__(self):
            if self.index >= len(self.data):
                raise StopIteration  # 发送迭代结束通知
            r = self.data[self.index]
            self.index += 1
            return r  # 返回此次提供的数据

    def __init__(self, iterable=()):
        self.data = [x for x in iterable]
    def append(self, v):
        self.data.append(v)
        # ...用于添加数据
    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __iter__(self):
        return MyList.MyIterator(self.data)

    def __len__(self):
        return len(self.data)  # self.data.__len__()

    def __add__(self, rhs):
        return MyList(self.data + rhs.data)

    def __mul__(self, rhs):
        print("__mul__")
        return MyList(self.data * rhs)

L1 = MyList([1, 2, 3])
L2 = MyList([4, 5, 6])
L3 = L1 + L2
print(L3)  # MyList([1, 2, 3, 4, 5, 6])
L4 = L2 + L1
print(L4)  # MyList([4, 5, 6, 1, 2, 3])

# 思考，能否实现MyList类型的对象与整数相乘?
L5 = L1 * 2
print(L5)

L6 = 2 * L1  # 等同于2.__add__(L1)
print(L6)














