  # 写一个类MyList 实现和list内几乎一样的功能 
  #   在MyList类内用列表来存储数据 
  # 如:
  #   class MyList:
  #       def __init__(self, iterable=()):
  #           self.data = [x for x in iterable]
  #       def append(self, v):
  #           ...用于添加数据
  #       ...
  #   L = MyList("ABCD")
  #   print(L)  # MyList(['A', 'B', 'C', 'D'])
  #   L.append('E')
  #   print(L)  # MyList(['A', 'B', 'C', 'D', 'E'])
  #   for x in L:
  #       print(x)  # A B C D E
  #   print("列表L的长度是:", len(L))  # 5


class MyList:
    class MyIterator:
        def __init__(self, lst):
            self.data = lst  # 绑定要迭代的列表　
            self.index = 0  # 迭代的起始位置

        def __next__(self):
            if self.index >= len(self.data):
                raise StopIteration  # 发送迭代结束通知
            r = self.data[self.index]
            self.index += 1
            return r  # 返回此次提供的数据

    def __init__(self, iterable=()):
        self.data = [x for x in iterable]
    def append(self, v):
        self.data.append(v)
        # ...用于添加数据
    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __iter__(self):
        return MyList.MyIterator(self.data)

    def __len__(self):
        return len(self.data)  # self.data.__len__()


L = MyList("ABCD")
print(L)  # MyList(['A', 'B', 'C', 'D'])
L.append('E')
print(L)  # MyList(['A', 'B', 'C', 'D', 'E'])
for x in L:
    print(x)  # A B C D E
print("列表L的长度是:", len(L))  # 5













