

# 此示例示意复合赋值算术运算符的重载 对函数全局变量的影响

class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __add__(self, rhs):
        print("__add__")
        return MyList(self.data + rhs.data)

    def __iadd__(self, rhs):
        print("__iadd__")
        self.data.extend(rhs.data)
        return self

s = "ABC"
def f(s1):
    s1 += "DEF"  # 等同于s1 = s1.__add__("DEF")

f(s)
print(s)

l = [1, 2, 3]
def f2(l2):
    l2 += [4, 5, 6]  # s1.__iadd__([4, 5, 6])
f2(l)
print(l)

L = MyList([1, 2, 3])
def f3(l2):
    l2 += MyList([4, 5, 6])
f3(L)
print(L)














