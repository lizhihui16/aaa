# property.py

# 此示例示意特性属性的用法
class Student:
    def __init__(self, score):
        self.__score = score

    @property
    def score(self):  # score = propery(score)
        '''实现getter'''
        return self.__score


    @score.setter
    def score(self, s):
        '''实现setter'''
        print("正在调用setter")
        if 0 <= s <= 100:
            self.__score = s
        else:
            raise ValueError

s = Student(59)
print(s.score)  # print(s.get_score())
s.score = 97  # s.set_score(97)
print(s.score)  # ...