# with.py


# 此示例示意with语句的用法

src_file = input("请输入源文件: ")
dst_file = input("请输入目标文件: ")

try:
    with open(src_file, 'rb') as src:
        # 准备打开别一个文件
        with open(dst_file, 'wb') as dst:
            # 开始读写文件
            b = src.read()
            dst.write(b)
except OSError:
    print("复制失败")

