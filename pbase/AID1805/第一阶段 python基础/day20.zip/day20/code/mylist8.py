

# 此示例示意[]运算符的重载
class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __getitem__(self, i):
        print("i =", i)
        if type(i) is slice:
            print("您正在执行切片取值操作")
            print("起始值是:", i.start)
            print("终止值是:", i.stop)
            print("步长是:", i.step)
        return self.data[i]

L1 = MyList([1, -2, 3, -4, 5])
x = L1[1:8:2]
print(x)  # 
