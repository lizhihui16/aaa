

# 此示例示意反向算术运算符的重载

class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __mul__(self, rhs):
        print("__mul__")
        return MyList(self.data * rhs)

    def __rmul__(self, lhs):
        print("__rmul__被调用")
        return MyList(self.data * lhs)

L1 = MyList([1, 2, 3])
L6 = 2 * L1  # 等同于2.__add__(L1) 或 L1.__rmul__(2)
print(L6)














