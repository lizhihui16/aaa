

# 此示例示意一元运算符的重载
class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __neg__(self):
        '''规则是正变负，负变正'''
        # L = [-x for x in self.data]
        L = (-x for x in self.data)
        return MyList(L)

L1 = MyList([1, -2, 3, -4, 5])
L2 = -L1  # 等同于L1.__neg__()
print(L2)



