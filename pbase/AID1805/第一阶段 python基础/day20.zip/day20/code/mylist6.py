

# 此示例示意一元运算符的重载
class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __contains__(self, e):
        return e in self.data

L1 = MyList([1, -2, 3, -4, 5])
if 3 in L1:
    print("3 在 L1内")
else:
    print("3 不在 L1内")

if 4 not in L1:
    print('4 不在L1内')
else:
    print('4 在L1内')



