

# 此示例示意复合赋值算术运算符的重载

class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return 'MyList(%r)' % self.data

    def __add__(self, rhs):
        print("__add__")
        return MyList(self.data + rhs.data)

    def __iadd__(self, rhs):
        print("__iadd__")
        self.data.extend(rhs.data)
        return self

L1 = MyList([1, 2, 3])
print('id(L1)=', id(L1))
L2 = MyList([4, 5, 6])
L1 += L2
print('id(L1)=', id(L1))
print("L1=", L1)

l1 = list([1,2,3])
l2 = list([4,5,6])
print('id(l1)=', id(l1))
l1 += l2
print('id(l1)=', id(l1))
print('l1=', l1)















