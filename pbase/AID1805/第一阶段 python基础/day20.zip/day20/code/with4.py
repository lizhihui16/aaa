# with4.py


# 此示例示意环境管理器类的定义的使用
class A:
    '''此类的对象可以用于with语句进行管理'''
    def __enter__(self):
        print("已经进入with语句")
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        print("已经离开了with语句")
        if exc_type is None:
            print("在with语句内部没有发生异常，正常离开with")
        else:
            print("离开with语句时出现异常")
            print("异常类型是:", exc_type)
            print("错误的值是:", exc_value)

try:
    with A() as a:
        print("这是with语句里打印的")
        3 / 0  # 触发异常
except:
    print("有异常发生，程序已转为正常！")

print("程序退出")


