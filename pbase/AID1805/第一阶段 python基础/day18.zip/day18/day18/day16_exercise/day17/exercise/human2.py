# 综合练习:
#   有两个人（ Human ）:
#     1. 姓名: 张三
#        年龄: 35岁
#     2. 姓名: 李四
#        年龄: 8岁
#     行为:
#       1. 教别人学东西 teach
#       2. 工作赚钱 work
#       3. 借钱 borrow
#     用程序描述如下事情:
#       张三 教 李四 学 python
#       李四 教 张三 学 滑冰
#       张三 上班 赚了 1000元钱
#       李四 向 张三 借了 200元钱
#       显示李四的全部信息
#       显示张三的全部信息

class Human:
    def __init__(self, name, age):
        self.name = name  # 姓名
        self.age = age  # 年龄
        self.money = 0  # 钱数
        self.skill = []  # 技能

    def teach(self, other, skl):
        other.skill.append(skl)  # other得到了技能
        print(self.name, '正在教', other.name,
              '学', skl)

    def work(self, money):
        self.money += money
        print(self.name, '上班赚了', money, '元钱')

    def borrow(self, other, money):
        '''借钱成功返回True,失败返回False'''
        # 先判断other没有没钱借
        if other.money > money:
            other.money -= money
            self.money += money
            print(other.name, '借给了',
                  self.name, money, '元钱')
            return True
        print(other.name, '没借给', self.name)
        return False  # 借钱失败

    def show_info(self):
        print(self.age, "岁的", self.name,
            '有技能:', self.skill, ',钱包内的钱数是',
            self.money)

zhang3 = Human("张三", 35)
li4 = Human('李四', 8)
zhang3.teach(li4, 'python')
li4.teach(zhang3, '滑冰')

zhang3.work(1000)  # 张三 上班 赚了 1000元钱
li4.borrow(zhang3, 200)  # 李四 向 张三 借了 200元钱

zhang3.show_info()
li4.show_info()