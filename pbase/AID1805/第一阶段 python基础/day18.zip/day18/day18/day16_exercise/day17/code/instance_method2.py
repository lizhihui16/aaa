# instance_method.py


# 此示例示意定义Dog类，并让Dog创建的对象有相同的行为
# 吃，睡，玩

class Dog:
    def eat(self, food):
        print("小狗正在吃", food)

    def sleep(self, hour):
        print("小狗睡了", hour, '小时')

    def play(self, obj):
        print("小狗正在玩", obj)

dog1 = Dog()  # 创建一个新的Dog类的对象
dog1.eat('骨头')
dog1.sleep(1)
dog1.play('球')


dog2 = Dog()
dog2.eat('包子')
dog2.sleep(3)
dog2.play('飞盘')

