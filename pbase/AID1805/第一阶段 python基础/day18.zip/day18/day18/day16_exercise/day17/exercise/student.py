# 练习:
#   写一个学生类, 用来描述学生信息
#    要求:
#      1) 为该类添加初始化方法，实现在创建对象时自动设置 '姓名', '年龄', '成绩' 属性
#      2) 添加 set_score 方法能为对象修改成绩信息, 并限制成绩在 0~100之间
#      3) 添加show_info方法打印学生对象的信息
#     class Student:
#         def __init__(.......):
#              .....
#         def set_score(self, score):
#             ....
#         def show_info(self):
#             ....

#     s1 = Student('小魏', 17, 59)
#     s1.set_score(68)
#     s1.show_info()  # 小魏 今年 17 岁, 成绩是: 68



class Student:
    def __init__(self, name, age, score=0):
        self.name = name
        self.age = age
        self.score = score

    def set_score(self, score):
        if 0 <= score <= 100:
            self.score = score
        else:
            # 通知调用者，调用实参不合法
            raise ValueError("值不在相应的范围内")

    def show_info(self):
        print(self.name, '今年', self.age,
              '岁, 成绩是:', self.score)

    def get_score(self):
        return self.score


s1 = Student('小魏', 17, 59)
s1.set_score(68)
s1.show_info()  # 小魏 今年 17 岁, 成绩是: 68

# print('s1 绑定的对象的成绩是:', s1.score)
print('s1 绑定的对象的成绩是:', s1.get_score())

