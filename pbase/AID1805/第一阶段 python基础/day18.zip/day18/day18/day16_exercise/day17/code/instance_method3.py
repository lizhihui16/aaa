# instance_method.py


# 此示例示意定义Dog类，并可以用help(Dog) 查看类的文档字符串

class Dog:
    '''这是自定义的类, 用来描述小动物行为'''
    def eat(self, food):
        '''描述小狗吃饭的行为...'''
        print("小狗正在吃", food)

    def sleep(self, hour):
        print("小狗睡了", hour, '小时')

    def play(self, obj):
        print("小狗正在玩", obj)


dog1 = Dog()  # 创建一个新的Dog类的对象
dog1.eat('骨头')
dog1.sleep(1)
dog1.play('球')


dog2 = Dog()
dog2.eat('包子')
dog2.sleep(3)
dog2.play('飞盘')

