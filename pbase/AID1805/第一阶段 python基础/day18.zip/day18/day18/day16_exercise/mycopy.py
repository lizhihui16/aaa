# 1. 写程序实现复制文件功能:
#   要求:
#     1) 多大的文件都能复制
#     2) 要能复制二进制文件
#     3) 要考虑关闭文件
#   如：
#     请输入源文件: ../day15.tar.gz
#     请输入目标文件: abc.tar.gz
#     已复制文件，文件长度是: ....

src_file = input("请输入源文件: ")
dst_file = input("请输入目标文件: ")

# 先打开源文件，准备读数据
try:
    src = open(src_file, 'rb')
    try:
        # 打开目标文件，准备写数据
        try:
            dst = open(dst_file, 'wb')
            try:
                # 开始复制文件，每次复制4K字节,直至复制完成
                while True:
                    b = src.read(4096)  # 4096 = 4k
                    if not b:
                        print("复制成功")
                        break
                    dst.write(b)
            finally:
                dst.close()
        except OSError:
            print("打开写文件", dst_file, '失败')
    finally:
        src.close()
except OSError:
    print("打开文件", src_file, "失败!")



