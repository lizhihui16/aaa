  # 3. 写一个生成器函数 myrange([start, ]stop[, step]) 来生成一系列整数
  #    要求:
  #      myrange功能与range功能完全相同
  #      不允许调用range(函数)
  #    用自己写的myrange结合生器表达式求1~10内奇数的平方和

def myrange(start, stop=None, step=1):
    if stop is None:
        stop = start
        start = 0
    if step > 0:
        while start < stop:
            yield start
            start += step
    elif step < 0:
        while start > stop:
            yield start
            start += step



print([x for x in myrange(10)])
print([x for x in myrange(5, 10)])
print([x for x in myrange(5, 10, 2)])
print([x for x in myrange(10, 0, -2)])
for x in myrange(20, 30):
    print(x)

 # 用自己写的myrange结合生器表达式求1~10内奇数的平方和

print(sum( (x ** 2 for x in myrange(1, 11) if x % 2) ))

