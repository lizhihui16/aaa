# 练习:
#   用类来描述一个学生的信息(可以修改之前写的Student类)

#   class Student:
#       ....此处自己实现

#   学生信息有:
#      姓名，年龄，成绩
#   将这些学生对象存于列表中,可以任意添加和删除学生信息
#      1) 打印学生的个数
#      2) 打印出所有学生的平均成绩
#      3) 打印出所有学生的平均年龄
#     (建议用类变量存储学生的个数)

class Student:
    count = 0
    def __init__(self, n, a, s):
        self.name, self.age, self.score = n, a, s
        self.__class__.count += 1
    def __del__(self):
        self.__class__.count -= 1
    

L = []
L.append(Student("小张", 20, 100))
L.append(Student("小李", 19, 97))

# L.remove(Student("小李", 19, 97))
del L[1]
L.append(Student("小赵", 18, 70))
L.append(Student("小姜", 17, 80))
print(L)

print("当前有%d个学生对象" % Student.count)
scores = 0
for s in L:
    scores += s.score
print("平均成绩是:", scores/Student.count)

ages =  sum( (s.age for s in L) )
print('平均年龄是:', ages/Student.count)