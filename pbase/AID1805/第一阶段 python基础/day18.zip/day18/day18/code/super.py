# super.py


# 此示例示意用super构造函数来间接调用父类的覆盖版本的方法

class A:
    def work(self):
        print("A.work()")

class B(A):
    def work(self):
        print("B.work()")

    def super_work(self):
        '''此方法先调用一下子类的work,
        再调用一下父类的work'''
        self.work()  # 调用自己的work
        # super(B, self).work()  # 调用父类的work
        super().work()  # 调用父类的work

b = B()
# b.work()  # B.work(),
# super(B, b).work()  # A.work()
b.super_work()
# super().work()  # 错的!!! super() 不能在方法使用
