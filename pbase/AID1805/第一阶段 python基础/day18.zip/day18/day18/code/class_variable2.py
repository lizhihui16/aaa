# class_variable.py


# 此示例示意类变量的用法，及类和对象的关系
class Human:
    total_count = 0  # 类变量，此变量用来记录所有对象的个数
    def __init__(self, n):
        self.name = n
        # 如果一个对象诞生，则将类变量的total_count做+1操作
        # 来记录当前对象的个数
        self.__class__.total_count += 1
    def __del__(self):
        self.__class__.total_count -= 1

print("当前有%d个Human的实例对象" % Human.total_count)
h1 = Human('小张')
print("当前有%d个Human的实例对象" % Human.total_count)
h2 = Human('小李')
print("当前有%d个Human的实例对象" % Human.total_count)
del h1  # 当对象销毁时。自动将类变量做减1操作
print("当前有%d个Human的实例对象" % Human.total_count)
