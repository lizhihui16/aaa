# slots.py


# 此示例示意__slots__属性的作用和用法
class Student:
    # 此列表让Student创建的对象只能用name和 age属性，
    # 不能有其它属性
    __slots__ = ['name', 'age']
    def __init__(self, name, age):
        self.name = name
        self.age = age

s1 = Student('Tarena', 15)
print(s1.age)  # 15
# s1.Age = 16  # 报错，不允添加__slots__列表以外的属性
print(s1.age)  # 16?

