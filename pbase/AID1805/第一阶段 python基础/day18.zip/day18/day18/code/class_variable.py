# class_variable.py


# 此示例示意类变量的用法，及类和对象的关系
class Human:
    total_count = 0  # 类变量，此变量用来记录所有对象的个数
    def __init__(self, n):
        self.name = n

print("Human类内的类变量Human.total_count=",
      Human.total_count)

# 类变量可以通过类直接访问
Human.total_count += 1
print("Human.total_count=", Human.total_count)

# 类变量可以通过类的实例直接访问
h1 = Human('小张')
print("h1.total_count=", h1.total_count)
h1.total_count = 100  # 此做法是为实例添加一个变量，并不是修改类变量
print('Human.total_count=', Human.total_count)  # 1

# 类变量可以通过此类的对象的 __class__属性间接访问
h1.__class__.total_count = 200
print("Human.total_count=", Human.total_count)  # 200

# h2 = Human('小李')

