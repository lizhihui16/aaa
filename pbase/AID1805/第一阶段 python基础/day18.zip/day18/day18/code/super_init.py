# super_init.py

class Human:
    def __init__(self, n, a):
        self.name = n
        self.age = a
        print("Human.__init__被调用")
    def infos(self):
        print("姓名:", self.name)
        print("年龄:", self.age)

class Student(Human):
    def __init__(self, n, a, s):
        super().__init__(n, a)  # 显式调用父类的初始化方法
        self.score = s
        print("Student.__init__被调用")

    def infos(self):
        super().infos()
        print("成绩:", self.score)

# h1 = Human('小张', 18)
# h1.infos()
s1 = Student("魏老师", 35, 60)
s1.infos()

