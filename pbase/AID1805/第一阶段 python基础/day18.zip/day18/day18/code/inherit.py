# inherit.py


# 此示例示意单继承的语句及定义方法
class Human:
    '''此类用于描述人类的共性行为'''
    def say(self, what):
        print("say:", what)
    def walk(self, distance):
        print("走了", distance, '公里')

class Student(Human):
    def study(self, subject):
        print("学习", subject)

class Teacher(Human):
    def teach(self, subject):
        print("正在教：", subject)

h1 = Human()
h1.say('今天天气真好')
h1.walk(5)
print('-----------------')
s1 = Student()
s1.walk(4)
s1.say("走的有点累")
s1.study('python')

print('---------------')
t1 = Teacher()
t1.say("今天晚饭吃什么?")
t1.walk(3)
t1.teach("继承/派生")



