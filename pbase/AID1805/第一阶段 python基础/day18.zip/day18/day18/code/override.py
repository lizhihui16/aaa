# override.py


class A:
    '''A类'''
    def work(self):
        print("A.work被调用!")

class B(A):
    '''B类'''
    def work(self):
        '''work 方法覆盖了父类的work'''
        print("B.work被调用!")

b = B()
b.work()  # B.work

a = A()
a.work()  # A.work
