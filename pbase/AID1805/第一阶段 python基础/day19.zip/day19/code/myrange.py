# myrange.py


# 此示例示意用自定义的类MyRange实现可迭代对象
# 用自定义的类MyIterator 实现迭代器

class MyIterator:
    def __init__(self, start, stop, step):
        # self.start变量用来记录迭代器的起始位置和当前位置
        self.start = start
        self.stop = stop
        self.step = step
    def __next__(self):
        '''此方法用于实现迭代器协议'''
        print("MyIterator.__next__方法被调用!")
        if self.start >= self.stop:  # 迭失终止条件
            raise StopIteration
        r = self.start  # 先将要返回的数存于变量r中
        self.start += self.step  # 迭代器后移
        return r  # 送回给next(it) 调用
class MyRange:
    def __init__(self, start, stop=None, step=1):
        if stop is None:
            stop = start
            start = 0
        self.start = start  # 起始值
        self.stop = stop    # 终止值
        self.step = step    # 步长
    def __repr__(self):
        return "MyRange(%d, %d, %d)" % (self.start,
            self.stop, self.step)
    def __iter__(self):
        '''此方法用于把MyRange类型创建的对象当做可迭代对象
        '''
        print("__iter__被调用")
        # 此处必须返回迭代器
        return MyIterator(self.start, self.stop, self.step)

L = [x for x in MyRange(5, 10)]
print(L)
print('----------------------------')
R = MyRange(5, 10, 2)
it = iter(R)  # R.__iter__
print(next(it))  # it.__next__

