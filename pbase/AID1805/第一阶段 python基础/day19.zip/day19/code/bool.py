# bool.py

# 此示例示意__bool__方法的重写方法及用法

class MyList:
    def __init__(self, iterable=()):
        self.data = [x for x in iterable]

    def __repr__(self):
        return "MyList(%s)" % self.data

    def __len__(self):
        print("__len__被调用")
        return len(self.data)
    def __bool__(self):
        '''此方法用来制定一个bool(x) 返回的规则'''
        # 如果没有任何元素返回False
        print("__bool__方法被调用")
        if len(self.data) == 0:
            return False
        for x in self.data:
            if x:
                return True
        return False

myl = MyList([1, -2, 3, -4])
# myl = MyList()
print(myl)
print(bool(myl))  # False
print(len(myl))

myl1 = MyList([0, 0.0, False, None])    
print(bool(myl1))  # False

myl2 = MyList([0, 1, 2])
print(bool(myl2))  # True
