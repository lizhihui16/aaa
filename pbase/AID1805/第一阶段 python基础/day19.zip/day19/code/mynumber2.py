# mynumber2.py


# 此示例示意自定义的对象转为python内键的数字类型
class MyNumber:
    def __init__(self, v):
        self.data = v
    def __repr__(self):
        return "MyNumber(%d)" % self.data
    def __int__(self):
        return int(self.data)

n1 = MyNumber(100.5)
n = int(n1)  # 自定义类型转为整数， 出错！！！
print(n)