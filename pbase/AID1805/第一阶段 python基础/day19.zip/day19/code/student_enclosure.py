class Student:
    def __init__(self, n, a, s):
       self.__name = n
       self.__age = a
    def set_age(self, a):
        if a < 0:
           raise ValueError("a < ")
        if a > 140:
           raise ValueError("a > 140")
        self.__age = a
        print("已经把年龄修改为" , a)
    def infos(self):
        print(self.__name, "的年龄", self.__age)

s1 = Student("小张", 20, 100)
s1.__age = 50
s1.infos()