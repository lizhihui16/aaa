# repr_str.py

# 此示例示意repr函数和str函数的不同

s = "I'm Teacher"

print(str(s))  

print(repr(s))


