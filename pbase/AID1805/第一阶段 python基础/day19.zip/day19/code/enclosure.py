# enclosure.py


# 此示例示意用私有属性和私有方法来进行封装
class A:
    def __init__(self):
        self.__p1 = 100  # 创建私有属性，此属性在类外无法访问

    def __m1(self):  # 私有方法
        print("__m1 私有方法被调用")

    def infos(self):
        print("A类的infos访问的__p1属性是:", self.__p1)
        self.__m1()  # 调用自己的私有方法
    
a = A()
# print(a.__p1)  # 出错
a.infos()
# a.__m1()  # 当前主模块不能调用A类的私有方法


