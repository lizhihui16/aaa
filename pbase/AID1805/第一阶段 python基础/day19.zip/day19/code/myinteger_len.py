
class MyInteger:
    def __init__(self, v):
        self.data = v

    def __repr__(self):
        return 'MyInteger(%d)' % self.data

    def __len__(self):
        return 10

i1 = MyInteger(-100)

print(len(i1))  # 出错
print(i1.__len__())
