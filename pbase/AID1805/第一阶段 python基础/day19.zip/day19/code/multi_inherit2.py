# multi_inherit2.py


# 小张写了一个类:
class A:
    def m(self):
        print("A.m() 被调用")

# 小李写了一个类B
class B:
    def m(self):
        print("B.m() 被调用")

# 小王感觉小张和小李写的两个类自己可以用
class AB(A, B):
    def m(self):
        print("AB.m() 被调用")
        super().m()
        super(A, self).m()

ab = AB()
ab.m()  # 当AB类没有覆盖父类的方法时会出现名字冲突问题



