class A:
    def go(self):
        print('A')

class B(A):
    def go(self):
        print('B')
        super(B, self).go()  # C

class C(A):
    def go(self):
        print('C')

class D(B, C):
    def go(self):
        print('D')
        super().go()  # B

d = D()
d.go()  # 'D'
