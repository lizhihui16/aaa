# mynumber.py


# 此示例示意repr(obj) 和str(obj) 的重写方法

class MyNumber:
    def __init__(self, value):
        self.data = value

    def __str__(self):
        # print('正在调用__str__方法，转换为普通字符串')
        s = "自定义数据：%d" % self.data
        return s

    def __repr__(self):
        return 'MyNumber(%d)' % self.data

n1 = MyNumber(100)
print(str(n1))

print(repr(n1))
