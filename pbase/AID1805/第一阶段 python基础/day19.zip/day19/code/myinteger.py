# myinteger.py

# 此示例示意 abs 和len方法的重写方法

class MyInteger:
    def __init__(self, v):
        self.data = v

    def __repr__(self):
        return 'MyInteger(%d)' % self.data

    def __abs__(self):
        '''此方法用于制定abs(obj) 函数取值时返回的结果'''
        if self.data < 0:
            # 用-self.data 创建一个新的对象返回回去
            t = MyInteger(-self.data)
            return t
        return MyInteger(self.data)

i1 = MyInteger(-100)

print(i1)  # 等同于print(str(i1)) 
n = abs(i1)
print(n)  # MyInteger(100)

i2 = MyInteger(200)
print(abs(i2))  # MyInteger(200)

