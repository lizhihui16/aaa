# 4. BMI指数(Body Mass Index) 又称身高体重指数
#    BMI公式: BMI = 体重(公斤)/ 身高(米)的平方
#   例如:
#     一个人 69公斤，　身高是173厘米
#     BMI = 69/1.73**2 得 23.05
#   标准表：
#   　　BMI < 18.5 体重过轻
#     18.5 <= BMI <= 24 正常范围
#     BMI > 24  体重过重
#     输入身高和体重，打印BMI值，并打印体重状况

height = float(input("请输入身高(米): "))
weight = float(input("请输入体重(公斤): "))
bmi = weight / height ** 2
print("BMI值为:", bmi)
if bmi < 18.5:
    print("您应当多吃点了!")
elif 18.5 <= bmi <= 24:
    print("正常")
else:
    print("您是不是应当给别人吃点!")
