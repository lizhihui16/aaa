# 2. 输入一个学生的三科成绩:
#   打印出最高分数是多少？
#   打印出最低分数是多少？
#   打印出平均分是多少？

a = int(input("请输入第1科成绩: "))
b = int(input("请输入第2科成绩: "))
c = int(input("请输入第3科成绩: "))

# 方法1
# if a > b:
#     if a > c:
#         zuida = a
#     else:
#         zuida = c
# else:
#     if b > c:
#         zuida = b
#     else:
#         zuida = c

zuida = a  # 先假设a最大
if b > zuida:
    zuida = b

if c > zuida:
    zuida = c

print("最大数是: ", zuida)
# 以下算法同学们自己实现