# str.py


print('welcome to beijing.\nI like python!\nI am Studing!')
print('''welcome to beijing.
I like python!
I am Studing!''')
