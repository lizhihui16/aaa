# # yanghui.py

#   3. 写程序打印杨辉三角(只打印6层)
#        1
#       1 1
#      1 2 1
#     1 3 3 1
#    1 4 6 4 1
#   1 5 10 10 5 1

def get_yanghui_list(n): # n代表层数
    '''此函数用于返回每一层的列表的列表'''
    layers = []  # 用于存储每一行的数据[[1], [1, 1], [1, 2, 1], ...]
    L = [1]
    for _ in range(n):  # 循环，每次加入layers中一行
        layers.append(L)  # 先把第一行加入
        # 算出下一行。再用L重新绑定
        one_line = [1]  # 最左边的1
        # 算出中间的数字
        for i in range(len(L) - 1):
            one_line.append(L[i] + L[i + 1])
        one_line.append(1)  # 加入最右边的1
        L = one_line  # 让L 绑定新算出的一行
    return layers

if __name__ == '__main__':
    # print(get_yanghui_list(6))
    for l in get_yanghui_list(6):
        print(l)
