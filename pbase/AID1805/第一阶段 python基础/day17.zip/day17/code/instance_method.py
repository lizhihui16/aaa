# instance_method.py


# 此示例示意定义Dog类，并让Dog创建的对象有相同的行为
# 吃，睡，玩

class Dog:
    def eat(self, food):
        print('id为', id(self), "的小狗正在吃", food)


dog1 = Dog()  # 创建一个新的Dog类的对象
print("dog1的id", id(dog1))
dog1.eat('骨头')


dog2 = Dog()
print("dog2的id", id(dog2))
dog2.eat('包子')

