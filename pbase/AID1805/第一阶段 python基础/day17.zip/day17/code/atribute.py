# atribute.py


# 此示例示意为每个对象添加实例属性，并通过对象的方法等访问 

class Dog:
    def infos(self):
        print(self.color, '的', self.kinds)

    def eat(self, food):
        '''
        当Dog类型的对象吃东西时，用food 属性记住
        此对象吃的是什么
        '''
        print(self.color, '的', self.kinds,
              '正在吃', food)
        self.food = food

    def food_info(self):
        print(self.color, '的', self.kinds,
            '上次吃的是', self.food)
dog1 = Dog()
dog1.kinds = '京巴'  # 为dog1绑定的Dog对象添加kinds属性
dog1.color = '白色'  # 创建color实例变量 
dog1.color = '黄色'  # 改变实例变量color的绑定关系

dog2 = Dog()  # 另一个对象
dog2.kinds = '导盲犬'
dog2.color = '黑色'

dog1.infos()
dog2.infos()
# print(dog1.color, '的', dog1.kinds)  # 获取属性的数据
# print(dog2.color, '的', dog2.kinds)

dog1.eat('骨头')
dog1.food_info()

# dog2.food_info()  # dog2没有food这个属性，调用出错
