# init_method.py


class Car:
    def __init__(self, clr, brand, model):
        self.color = clr  # 颜色
        self.brand = brand  # 品牌
        self.model = model  # 型号
        # print('Car的初始化方法被调用')

    def run(self, speed):
        print(self.color, '的', self.brand,
              self.model, '正在以', speed, 
              '公里/小时的速度行驶')














c1 = Car('红色', '奥迪', 'A6')
c1.run(200)


# c2 = Car('蓝色', 'TESLA', 'Model S')
# c2.run(180)
