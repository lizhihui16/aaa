# del_method.py

# 此示例示意析构方法的用法
class Car:
    def __init__(self, name):
        self.name = name
        print("汽车", name, '对象被创建')

    def __del__(self):
        print("汽车", self.name, '对象被销毁')

c1 = Car("BYD E6")
# del c1
# L = []
# L.append(c1)
c1 = None  # 让c1变量绑定None
while True:
    pass

print("程序结束")

