# class.py


# 此示例示意定义最简单一个类
class Dog:
    '''这个类用于描述一种小动物的行为和属性'''
    pass

dog1 = Dog()  # 创建一个新的Dog类的对象
print(id(dog1))  # 打印这个对象的id

dog2 = Dog()  # 创建另一个Dog类的对象
print(id(dog2))

# 对比
lst1 = list()  # 创建一个空列表
print(id(lst1))

lst2 = list()  # 创建另一个空列表
print(id(lst2))

lst1.append(100)
lst2.append(200)
# dog1.append(10000)  # 只要在类中添加方法就可以实现此操作
# dog2.append(20000)

