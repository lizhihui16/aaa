# 1. 分三次输入当前的时间：
# 　　　小时，分钟，秒
#   在终端打印此时间距离　0:0:0过了多少秒

s = input("请输入小时: ")
hour = int(s)  # 将字符串转为整数

s = input("请输入分钟: ")
minute = int(s)

s = input("请输入秒: ")
second = int(s)

# print(hour, minute, second)
second_result = (hour * 60 * 60 + 
    minute * 60 + second)

print("距离0:0:0", second_result, "秒")


