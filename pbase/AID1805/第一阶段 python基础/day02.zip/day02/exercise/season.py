# 1. 输入一个季度 1 ~ 4, 输入这个季度有哪儿几个月
# ，如果输入的不是1~4之间的数，则提示用户您输错了


season = input("请输入一个季度(1~4): ")
season = int(season)
if season == 1:
    print("春季有: 1, 2, 3月")
elif season == 2:
    print("夏季有: 4, 5, 6月")
elif season == 3:
    print("秋季有: 7, 8, 9月")
elif season == 4:
    print("冬季有: 10, 11, 12月")
else:
    print("您的输入有误!")

