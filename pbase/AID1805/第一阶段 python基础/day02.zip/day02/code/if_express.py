# if_express.py

# 此示例示意条件表达式的用法
# 商场促销，满100减20
money = int(input("请输入商品总额: "))

pay = money - 20 if money >= 100 else money  # 需要支付的钱

print("您需要支付:", pay, "元")
