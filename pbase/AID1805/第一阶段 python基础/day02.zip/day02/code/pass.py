# pass.py


# 输入一个学生的成绩，
# 如果不在0~100范围内，
# 则提示您输入的有误

score = int(input('请输入学生成绩'))
if 0 <= score <= 100:
    pass
else:
    print("您的输入有误!")