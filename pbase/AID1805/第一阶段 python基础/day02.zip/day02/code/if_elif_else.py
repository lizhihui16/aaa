

# 此示例示意 if_elif_else组合使用
# 问题:
#   请输入一个数，判断这个数是正数，零，还是负数
n = int(input('请输入一个整数:　'))

if n > 0:
    print("正数")
elif n == 0:
    print("零")
else:
    print("负数")

