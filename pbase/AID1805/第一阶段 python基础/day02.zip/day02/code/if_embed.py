# if_embed.py

# 此示例示意if语句嵌套
# 问题：
# 　　输入一个学生的成绩:
#   根据等级打印出,优，良，及格，不及格
score = int(input("请输入学生成绩: "))
if 0 <= score <= 100:
    print("成绩合法")
    if score >= 90:
        print("优")
    elif score >= 80:
        print("良")
    elif score >= 60:
        print("及格")
    else:
        print("不及格")

else:
    print("您的输入有误！")
