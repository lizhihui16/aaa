# input.py

s = input("请输入字符串: ")

print("您刚才输入的是:", s)

s = input("请输入整数: ")
i = int(s)  # 将字符串通过int转为整数
print(i == 100)  # True/Flase