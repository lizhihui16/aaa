

# print('hello')

# x = 100 + 200

# print(x)

# del x

# 以下示意多条语句也可以写在一起，用分号; 分隔开即可
print('hello'); x = 100 + 200; print(x); del x


