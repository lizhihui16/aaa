# if.py


# 让用户输入一个整数，让程序打印出用户输入
#   的数是奇数还是偶数

num = int(input("请输一个整数: "))
if num % 2 == 0:
    print("您输入的是偶数")
else:
    print("您输入的是奇数")





