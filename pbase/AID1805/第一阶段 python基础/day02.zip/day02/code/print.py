# print.py

# 此示例示意print函数的用法及相应的关键字参数的用法

print(1, 2, 3, 4)
print(True, None, 3.14, 1+2J, 100)

print(1, 2, 3, 4, sep=' ')
print(1, 2, 3, 4, sep='#')
print(1, 2, 3, 4, sep=' <-> ')

print(1, 2, 3, 4)
print(1, 2, 3, 4, end='\n')
print(1, 2, 3, 4, end='')
print('hello \n\n\n world')
