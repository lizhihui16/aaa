# 从凌晨0:0:0 计时，到现在已经过63320秒
# 请问现在是几时，几分，几秒

s = 63320

hour = s // 60 // 60 
# minute = s % (60 * 60) // 60
minute = s // 60 % 60
secode = s % 60
print(hour, ":", minute, ":", secode)
