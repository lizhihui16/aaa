# 练习:
#   输入三行文字，让这三行文字依次以20个字符的宽度右对齐输出:
#     如:
#       请输入第1行: hello world
#       请输入第2行: abcd
#       请输入第3行: a
#     输出结果为:
#          hello world
#                 abcd
#                    a
#   做完上面的题后再思考:
#     能否以最长字符串的长度进行右对齐显示(左侧填充空格)

a = input('请输入第1行: ')
b = input('请输入第2行: ')
c = input('请输入第3行: ')

# 求最大长度
length = len(a)
if len(b) > length:
    length = len(b)
if len(c) > length:
    length = len(c)

# 方法1
# print(' ' * (length - len(a)) + a)
# print(' ' * (length - len(b)) + b)
# print(' ' * (length - len(c)) + c)

# 方法2
# fmt = "%" + str(length) + 's'
fmt = "%%%ds" % length
print('fmd = ', fmt)
print(fmt % a)
print(fmt % b)
print(fmt % c)