# 1. 输入一个开始的整数用变量begin绑定，输入一个结
#    束的整数变量end绑定，打印从begin开始到end结
#    束(不包含end)的全部整数(要求打印在一行内)
#   如:
#    请输入开始数:8
#    请输入结束数:20
#    8 9 10 11 12 ...... 18 19

begin = int(input("请输入开始数: "))
end = int(input("请输入结束数: "))
i = begin
while i < end:
    print(i, end=' ')
    i += 1
else:
    print()  # 在条件不满足结束循环时，打印换行