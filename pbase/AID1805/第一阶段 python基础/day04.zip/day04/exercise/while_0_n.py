
# 练习:
#   输入一个整数n, 打印 0 ~ n之间的整数(不包含n),
#   每个数字打印一行

n = int(input("请输入整数: "))

i = 0
while i < n: 
    print(i)
    i += 1

