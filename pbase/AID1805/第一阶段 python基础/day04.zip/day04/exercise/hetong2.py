# 练习：
#   写一个程序，定义一个合同的模板：
#             《合同》
#     甲方: ______     乙方:______
#     合同金额: ____元
#     .....
#     日期:____年__月__日

#   写程序输入相应的参数，打印出完整的合同文本信息:
#     如:
#        请输入甲方姓名: xxxx
#        请输入乙方姓名: yyyy
#        请输入合同额: 10000
#        请输入年: 2018
#        .....

hetong = '''        《合同》
甲方: __%s__     乙方:__%s__
合同金额: _%d_元
.....
日期:_%d_年_%d_月_%d_日
'''

name1 = input("请输入甲方姓名: ")
name2 = input("请输入乙方姓名: ")
money = int(input("请输入合同额: "))
year = int(input("请输入年: "))
month = int(input("请输入月: "))
day = int(input("请输入日: "))

print(hetong % (name1,
                name2,
                money,
                year,
                month,
                day
                ))


# print("        《合同》")
# print("甲方: _%s_     乙方:_ %s__" % (name1, name2))
# print("合同金额: _%d_元" % money)
# print(".....")
# print("日期:_%d_年_%d_月_%d_日" % (year, month, day))

