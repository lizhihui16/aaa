# 2. 输入一个开始的浮点数用begin绑定，输入一个结束
#    的浮点数用end绑定，输入每个数的间隔用step来绑定
#   如:
#     请输入开始数: 5
#     结束输结束数: 20
#     请输入步长: 3
#   打印如下数字（不包含end):
#     5 8 11 14 17

begin = float(input("请输入开始数: "))
end = float(input("结束输结束数: "))
step = float(input("请输入步长: "))

i = begin
while i < end:
    print(i, end=' ')
    i += step
print()