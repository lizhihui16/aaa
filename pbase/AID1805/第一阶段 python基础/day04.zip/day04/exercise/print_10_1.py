# 1. 用while 语句打印 10 ~ 1的整数

i = 10
while i > 0:
    print(i, end=' ')
    i -= 1

print()