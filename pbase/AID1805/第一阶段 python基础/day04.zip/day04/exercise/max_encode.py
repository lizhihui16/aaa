# 3. 输入一个字符串，将字符串中Unicode编码值最大
#  的一个字符的编码值和这个字符打印出来

s = input("请输入字符串: ")
i = 0  # i代表字符串的索引
encode_max = ord(s[0])  # 先假设第一个最大
while i < len(s):
    if ord(s[i]) > encode_max:
        encode_max = ord(s[i])
    i += 1

print("编码值最大是:", encode_max)
print("这个字符是:", chr(encode_max))
