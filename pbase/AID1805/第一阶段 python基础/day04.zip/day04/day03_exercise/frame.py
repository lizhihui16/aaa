# 3. 输入三行文字，让这三行文字在一个方框内居中显示
#   如输入(不要输入中文）:
#     hello!
#     I'm studing python!
#     I like python
#   显示如下:
#    +---------------------+
#    |       hello!        |
#    | I'm studing python! |
#    |    I like python    |
#    +---------------------+

a = input("请输入第1行字符串: ")
b = input("请输入第2行字符串: ")
c = input("请输入第3行字符串: ")

length = len(a)
if len(b) > length:
    length = len(b)
if len(c) > length:
    length = len(c)

# print("最长的一个字符串的宽度是: ", length)

line1 = '+' + '-' * (length + 2) + '+'
print(line1)
print('| ' + a.center(length) + ' |')
print('| ' + b.center(length) + ' |')
print('| ' + c.center(length) + ' |')
print(line1)