# break_while_embed.py


s = 1
while s < 5:
    g = 0
    while g < 10:
        print(s, g)
        if g == 5:
            break
        g += 1
    s += 1

print("程序结束")