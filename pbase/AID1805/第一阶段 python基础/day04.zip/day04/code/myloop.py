# myloop.py

# 任意输入一些正整数，当输入小于零的数时结束输入
# 求刚才输入这些数的和

s = 0  # 此变量用于累加数据，初值为零
while True:
    n = int(input("请输入: "))
    if n < 0:
        break  # 终止死循环
    # print("您刚才输入的是:", n)
    s += n  # 把用户输入的数字累加到s中
else:
    print("这条语句永远不会执行!")

print("您输入的这些数的和是:", s)