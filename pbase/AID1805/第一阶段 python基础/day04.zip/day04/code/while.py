# while.py


# 问题:
#   输入一个整数n，根据这个整数打印n行的"hello"
n = int(input("请输入整数: "))

i = 0
while i < n: 
    print('hello')
    i += 1
else:
    print("i < n 此时为False才会执行我这一条语句")
    print("此时i=", i, "n=", n)
print("程序结束")