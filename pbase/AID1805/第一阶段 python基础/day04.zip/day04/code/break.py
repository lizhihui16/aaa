# break.py

# 此示例示意break语句的用法

i = 1
while i < 6:
    print("循环开始时:", i)
    if i == 3:
        break
    print("循环结束时:", i)
    i += 1
else:
    print(i, "< 6 条件不成立")

print("while 语句结束，此时i的值为:", i)