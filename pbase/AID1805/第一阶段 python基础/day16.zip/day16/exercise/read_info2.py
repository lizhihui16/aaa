# 

def read_file_content():
    L = []
    try:
        f = open('info.txt')
        while True:
            s = f.readline()  # '小张 20 100\n'
            if not s:
                break
            s2 = s.strip()  # '小张 20 100'
            name_age_score = s2.split()  # ['小张', '20', '100']
            n, a, s = name_age_score
            d = {'name': n, 'age': int(a), 'score': s}
            # d =  {'name': '小张', 'age': 20, 'score': 100}
            L.append(d)


        f.close()
    except OSError:
        print('打开文件失败')
    return L

if __name__ == '__main__':
    docs = read_file_content()
    print(docs)

