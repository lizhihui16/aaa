
# 2. 写一个程序读入infos.txt中的内容，以如下格式打印 infos.txt中的内容
#    姓名: xxx, 年龄 20, 住址: XXXX
#    姓名: yyy, 年龄 18, 住址: YYYYYY

file = open('infos.txt', 'rt')

for line in file:
    s = line.strip()  # 去掉左右的空白字符
    lst = s.split(',')
    # print(lst)
    n, a, addr = lst  # 序列赋值
    a = int(a)  # 将年龄转为整数
    print('姓名: %s, 年龄 %d, 住址: %s' % (n, a, addr))


file.close()
