# 

def read_file_content():
    try:
        f = open('info.txt')
        s = f.read()
        print("文件内容是:", s)
        f.close()
    except OSError:
        print('打开文件失败')


if __name__ == '__main__':
    read_file_content()

