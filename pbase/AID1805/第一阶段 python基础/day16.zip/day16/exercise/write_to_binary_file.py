
# 练习:
#   将如下数据用二进制文件操作方式写入到文件data.txt中
#   数据如下:
#   小李 13888888899
#   小王 13666666666
#      提示: b = str.encode('utf-8')
#   用 sublime text3 打开，看写入的内容能否被sublime识别并读出
  
name1 = '小李'
number1 = 13888888899
name2 = '小王'
number2 = 13666666666

file = open("data.txt", 'wb')

s = name1 + ' ' + str(number1) + '\n'
b = s.encode('utf-8')
file.write(b)  # 写入第一行数据
s = name2 + ' ' + str(number2) + '\n'
b = s.encode('utf-8')
file.write(b)  # 写入第二行数据

file.close() 


