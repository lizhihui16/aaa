# 1. 写一个程序，输入很多人的姓名，年龄，家庭住址信息,存入文件
#   'infos.txt' 中
#   文件格式自己定义
#   完成输入后查看文件格式是否是你想要的格式(文本文件操作)

file = open('infos.txt', 'w')

while True:
    n = input("请输入姓名: ")
    if n == '':
        break
    a = int(input('请输入年龄: '))
    addr = input("请输入住址: ")
    # 写入到文件中:
    file.write(n)
    file.write(',')
    file.write(str(a))
    file.write(',')
    file.write(addr)
    file.write('\n')

file.close()











