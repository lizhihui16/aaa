# file_read_text.py

# 此示例示意以文本文件模式读取myfile.txt中的内容
try:
    f = open("myfile.txt")
    print('打开文件成功!')
    # 读取文件内容
    while True:
        s = f.readline()
        if s == '':
            print('已经读取到了文件末尾')
            break
        print("读到这一行是:", s)


    f.close()
except OSError:
    print("打开文件失败")
