# file_write_text.py


# 此示例示意写文本文件操作

f = open('mynote.txt', 'at')  # 'a' 代表追加方式打开

f.write('我追加到了文件尾')

f.close()