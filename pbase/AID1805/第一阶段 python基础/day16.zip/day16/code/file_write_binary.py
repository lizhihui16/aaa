# file_write_binary.py


# 此示例示意以二进制方式写文件到'data.bin'
try:
    f = open('data.bin', 'wb')
    print("打开文件成功")
    # 写入数据
    b = b'\xe4\xb8\xad'
    f.write(b)
    f.write(b'\x00\x00')

    f.close()
except OSError:
    print("打开文件失败")