# file_read_text.py

# 此示例示意以文本文件模式读取myfile.txt中的内容
try:
    f = open("myfile.txt")
    print('打开文件成功!')
    # 读取文件内容
    # s = f.read()
    s = f.read(3)  # 读取三个字符
    print('字符串s的长度是:', len(s), '内容是', s) # 'abc'
    s2 = f.read(3)
    print('第二次读取的字符是:', s2)  # '123'
    s3 = f.read(5)
    print('第三次拿到的字符是:', s3)  # '中文\nAB'
    s4 = f.read()
    print(s4)  # 'C英文\nhello world\n'

    f.close()
except OSError:
    print("打开文件失败")
