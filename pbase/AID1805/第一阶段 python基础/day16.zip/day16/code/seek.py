# seek.py

# 此示例示意 用F.seek方法来定位文件的读写位置
# 注: seek 通常对 二进制模式打开的文件进行操作

f = open('myfile.bin', 'rb')
print("刚打开文件时，文件的读写位置是:", f.tell())  #0

b = f.read(2)
print('刚读入的内容是:', b)
print('读取两个字节后的读写位置是:', f.tell())  # 2

# 想读取第五个字节开始的5个字节
# 定位
# f.seek(5, 0)  # 从头开始向后移动5个字节的位置
# f.seek(3, 1)  # 从当前的读写位置向后移动3个字节的位置
f.seek(-15, 2)  # 从文件尾向前移动15个字节的位置

print("seek 移动后的读写位置是:", f.tell())  # 5
b = f.read(5)  # 读取5个字节
print(b)  # b'abcde'

f.close()

