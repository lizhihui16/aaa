# file_read_binary.py


file = open('data.bin', 'rb')

b = file.read(1)  # 读取一个字节
print("第一个字节是:", b)

b = file.read() # 读取所有的字节
print('其它所有字节是: ', b)
file.close()
