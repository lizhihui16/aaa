# file_open.py


# 此示例示意文件的打开，读取及关闭

# 第一步打开文件
try:
    f = open('myfile.txt', 'rt')
    # f = open('/aaaaaaaaaa.txt', 'rt')
    print("打开文件成功!")

    # 第二步读取文件
    s = f.read()  # 读取全部内容形成字符串用s绑定
    print("文件中的内容是:", s)

    # 第三步，关闭文件
    f.close()
    print("文件已关闭")
except OSError:
    print("文件打开失败")



