# read_hanzi.py


f = open('hanzi_gbk.txt', 'rb')
b = f.read()  # 读取字节串
s = b.decode('gbk')  # 将gbk字节串解码为UNICODE字符串
# s = f.read()
print(s)

f.close()