# file_write_text.py


# 此示例示意写文本文件操作

f = open('mynote.txt', 'w')  # 'w' 代表以写模式打开文件

f.write('你好')
f.write('中国!')
f.write('\n')
f.write("hello china!")
f.writelines(['aaaa\n', 'bbbb\n', 'cccc\n'])

f.close()