# iterator.py

# 此示例示意用while 语句和迭代器来访问列表
L = [2, 3, 5, 7]
it = iter(L)  # 先拿到用于访问L的迭代器
while True:
    try:
        x = next(it)
        print(x)
    except StopIteration:
        break

print('----------------')
for x in L:
    print(x)





