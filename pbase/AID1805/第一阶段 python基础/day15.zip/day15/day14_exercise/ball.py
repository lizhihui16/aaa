# 1. 一个球从100米高空落下，每次落地后反弹高度为原高
#    度的一半，再落下，写程序
#    1) 算出皮球在第10次落地后反弹多高
#    2) 打印出皮球共经历了多少米路程


# 1) 算出皮球在第10次落地后反弹多高
# 用循来来实现
def get_last_height(height, times):
    for _ in range(times):
        height /= 2
    return height

# 用递归来实现
# def get_last_height(height, times):
#     if times == 0:
#         return 100
#     return get_last_height(height, times - 1) / 2

print(get_last_height(100, 10))


# 2) 打印出皮球共经历了多少米路程
def get_distance(height, times):
    s = 0
    for _ in range(times):
        s += height + height / 2
        height /= 2
    return s

print(get_distance(100, 10))

