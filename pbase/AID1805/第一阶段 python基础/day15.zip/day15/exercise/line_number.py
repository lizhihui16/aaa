# 练习:
#   写一个程序，读入任意行文字，当输入空行时结束输入
#     打印带有行号的输入结果
#       如:
#         请输入:hello
#         请输入:world
#         请输入:python
#         请输入:<回车>
#       输入如下:
#         第1行: hello
#         第2行: world
#         第3行: python

def read_lines():
    '''此函数读取用户输入的信息'''
    L = []
    while True:
        s = input("请输入: ")
        if not s:
            break
        L.append(s)
    return L


# def print_lines(L):
#     '''打印带有行号的文字信息'''
#     for t in enumerate(L, 1):
#         print("第%d行: %s" % t)

def print_lines(L):
    '''打印带有行号的文字信息'''
    i = 1
    for text in L:
        print("第%d行: %s" % (i, text))
        i += 1


if __name__ == '__main__':
    lines = read_lines()
    # print(lines)
    print_lines(lines)


