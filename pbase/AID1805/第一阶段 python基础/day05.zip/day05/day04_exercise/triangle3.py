# 3. 写程序，输入一个整数n代表直角三角形的宽度,打印出相应的直角三角形.
#   如:
#     请输入三角形宽度: 4
# 5. 修改第3题， 打印如下三解形:
#   ****
#    ***
#     **
#      *

n = int(input("请输入三角形宽度: "))
line = 1  # line代表行数
while line <= n:
    # 计算空格的个数: 行数减１
    blank_count = line - 1
    # 星号个数等于: 宽度减空格个数
    starts = n - blank_count
    print(' ' * blank_count + '*' * starts)
    line += 1

