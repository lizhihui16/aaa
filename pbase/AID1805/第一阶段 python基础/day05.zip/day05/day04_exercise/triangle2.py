# 3. 写程序，输入一个整数n代表直角三角形的宽度,打印出相应的直角三角形.
#   如:
#     请输入三角形宽度: 4
#   打印如下:
#        *
#       **
#      ***
#     ****

n = int(input("请输入三角形宽度: "))
line = 1  # line代表行数
while line <= n:
    # 计算空格的个数: 宽度减行数
    blank_count = n - line
    print(' ' * blank_count + '*' * line)
    line += 1

