# 练习:
#   1. 任意输入一个字符串:
#     1) 计算您输入的空格的个数，并打印出来
#     2) 计算您输入的'a' 字符的个数，并打印出来
#       (要求用for语句实现)
#     思考:
#       用while语句能否实现上述功能?

s = input("请输入一行字符串: ")
count_blank = 0
for char in s:
    if char == ' ':  # 如果这个字符正好是空格
        count_blank += 1  # 则计数变量加1
else:
    print("空格的个数是: ", count_blank)


count_a = 0
for char in s:
    if char == 'a':  # 如果这个字符正好是空格
        count_a += 1  # 则计数变量加1
else:
    print("a的个数是: ", count_a)
