# 练习:
#   输入一个起始数用start绑定, 输入一个结束数用stop绑定
#   打印start 到 stop(不包含stop)内的所有的奇数
#     (用什么方法都可以)

start = int(input("请输入起始数: "))
stop = int(input("请输入终止数: "))

for x in range(start, stop):
    if x % 2 == 0:
        continue
    print(x)
