# 2. 用for 语句打印 1 ~ 20, 每5个打印在一行内

for x in range(1, 21):
    print(x, end=' ')
    if x % 5 == 0:
        print()
else:
    print()  #  换行