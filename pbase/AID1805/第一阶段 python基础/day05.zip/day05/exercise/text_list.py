# 2. 输入任意行文字，存于列表L中，当不输入内容回车后
#    退出输入，
#   1) 打印L列表中的内容
#   2) 计算您共输入的几行内容
#   3) 计算您共输入了多少个字符

L = []
while True:
    s = input("请输入: ")
    if not s:
        break
    # L = L + [s]
    L += [s]
    # L += s
print("L绑定的列表是: ", L)

count = 0
for x in L:
    count += 1

print("您刚才输入行数是：", count)
count_char = 0
for x in L:
    count_char += len(x)
print("您刚才输入了%d个字符" % count_char)
