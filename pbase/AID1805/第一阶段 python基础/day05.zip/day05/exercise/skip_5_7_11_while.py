# 练习:
#   2, 求 1 ~ 100 之间所有不能被 5, 7, 11 整除的
#      数以及这些数的和

s = 0  # 用来保存和
x = 1
# for x in range(1, 100):
while x < 100:
    if x % 5 == 0 or x % 7 == 0 or x % 11 == 0:
        x += 1
        continue
    print(x)
    s += x
    x += 1  # 修改循环变量

print('以上所有数的和是:', s)