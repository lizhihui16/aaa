# 练习:
#   2, 求 1 ~ 100 之间所有不能被 5, 7, 11 整除的
#      数以及这些数的和

s = 0  # 用来保存和
for x in range(1, 100):
    if x % 5 == 0:
        continue
    if x % 7 == 0:
        continue
    if x % 11 == 0:
        continue
    print(x)
    s += x

print('以上所有数的和是:', s)