# 1. 用for 语句打印 1 ~ 20, 打印在一行内

for x in range(1, 21):
    print(x, end=' ')
else:
    print()  #  换行