# 2. 计算　1 + 3 + 5 + 7 + .... +97 + 99的和
#   分别用for 和 while 循环语句来实现

# 用for语句实现
s = 0  # 用于累加和
for x in range(1, 100, 2):
    s += x
else:
    print("用for语句求的和是:", s)

# 用while语句实现
s = 0
x = 1
while x < 100:
    s += x
    x += 2
else:
    print("用while语句求的和是:", s)





