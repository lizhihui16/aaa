# continue.py


# 此示例示意contine语句跳过奇数打印偶数

# 打印20以内的全部偶数
for x in range(20):
    # 判断如果x是奇数，则取下一个数
    if x % 2 == 1:
        continue
    print(x)





