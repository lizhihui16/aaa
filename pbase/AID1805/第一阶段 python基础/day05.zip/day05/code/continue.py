# continue.py


# 此示例示意contine语句的用法
for x in range(5):
    if x == 2:
        continue
    print(x)



