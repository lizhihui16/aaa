# for.py


# 此示例示意用for语句的用法

s = 'ABCDE'
for ch in s:
    print("ch -->>", ch)
else:
    print("可迭代对象已经不能再提供数据了!")

print('程序结束')

