# range.py


# 此示例示意range函数的用法
# for x in range(4):
#     print(x)  # 0, 1, 2, 3\

# for x in range(3, 6):
#     print(x)  # 3, 4, 5

for x in range(5, 0, -2):
    print(x)

