#! /usr/bin/python3

print("hello world!")
# print("hello tarena!")
print("today is friday!")


